package br.edu.atitus.paradigma.saudacao_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaudacaoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
