INSERT INTO cambio (origem, destino, fator) VALUES
  ('USD', 'BRL', 5.5711),
  ('USD', 'EUR', 0.902),
  ('USD', 'UYU', 41.07),
  ('USD', 'ARS', 959.00),
  ('USD', 'GBP', 0.761);