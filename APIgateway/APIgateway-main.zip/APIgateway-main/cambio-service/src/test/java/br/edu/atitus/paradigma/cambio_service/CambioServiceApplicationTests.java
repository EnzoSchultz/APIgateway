package br.edu.atitus.paradigma.cambio_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CambioServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
