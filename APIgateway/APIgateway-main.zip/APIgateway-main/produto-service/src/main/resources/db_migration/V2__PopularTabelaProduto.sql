INSERT INTO produto (marca, modelo, valor) VALUES
  ('Apple', 'iPhone 15 256GB', 1022.96),
  ('Motorola', 'G85 256GB', 306.78),
  ('Xiomi', 'Redmi 13C 256GB', 242.15),
  ('Samsung', 'S23 Ultra 256GB', 768.70);